//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<tapjoy_offerwall/TapjoyOfferwallPlugin.h>)
#import <tapjoy_offerwall/TapjoyOfferwallPlugin.h>
#else
@import tapjoy_offerwall;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [TapjoyOfferwallPlugin registerWithRegistrar:[registry registrarForPlugin:@"TapjoyOfferwallPlugin"]];
}

@end
